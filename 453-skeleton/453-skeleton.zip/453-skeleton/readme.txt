CPSC 453 Assignment 1
Tyler Shenassa
30023002


Hello, 

Please use UP and DOWN arrows to iterate thru different fractals.

LEFT and RIGHT arrows will decrease / increase iterations. 

If the window is too large / small, size can be edited in main.cpp line 96 (please keep square or shapes will be distorted). Default is 1080x1080.

If more iterations are desired and your system is up to it, visit line 48 of main.cpp. Default value is 6.


Project completed in Windows 10, with Visual C++ 2019.



